Configuration Main
{
	Param ( [string] $nodeName, [string] $PBIDLink, [string] $PBIDProductId )

	Import-DscResource -ModuleName PSDesiredStateConfiguration
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc -ModuleVersion "1.2.0.0"
	Import-DscResource -module xChrome -Name MSFT_xChrome -ModuleVersion "1.1.0.0"
	Import-DscResource -module xPSDesiredStateConfiguration -Name xRemoteFile -ModuleVersion "4.0.0.0"

	Node $nodeName
	{

		xIEEsc DisableIEEscAdmin
		{
			IsEnabled = $false
			UserRole  = "Administrators"
		}

		xIEEsc DisableIEEsc
		{
			IsEnabled = $false
			UserRole = "Users"
		}

		Registry EnableDownloads
		{
			Ensure = "Present"
			Key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3"
			ValueName = "1803"
			ValueData = "0"
			ValueType = "Dword"
		}

		Registry DisablePopUp
		{
			Ensure = "Present"
			Key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3"
			ValueName = "1809"
			ValueData = "3"
			ValueType = "Dword"
		}

		Registry DoNotOpenServerManager
		{
			Ensure = "Present"
			Key = "HKLM:\SOFTWARE\Microsoft\ServerManager"
			ValueName = "DoNotOpenServerManagerAtLogon"
			ValueData = "1"
			ValueType = "Dword"
		}
		
		MSFT_xChrome chrome
		{
			Language = "en"
			LocalPath = "$env:SystemDrive\Windows\DtlDownloads\GoogleChromeStandaloneEnterprise.msi"
		}
		
		xRemoteFile PBIDownload
		{
			Uri = $PBIDLink
			DestinationPath = "c:\temp\PowerBIDesktop.msi"
		}
		
		Package Installer
		{
			Ensure = "Present"
			Path = "c:\temp\PowerBIDesktop.msi"
			Name = "Microsoft Power BI Desktop (x64)"
			ProductId = $PBIDProductId
			DependsOn = "[xRemoteFile]PBIDownload"
			Arguments = "ACCEPT_EULA=1 /quiet"
			LogPath = "c:\temp\PowerBIDesktop_InstallLog.log"
		}

		xRemoteFile gitDownload
		{
			Uri = "https://github.com/git-for-windows/git/releases/download/v2.14.1.windows.1/Git-2.14.1-64-bit.exe"
			DestinationPath = "c:\temp\Git-2.14.1-64-bit.exe"
		}

		Package Installer
		{
			Ensure = "Present"
			Path = "c:\temp\Git-2.14.1-64-bit.exe"
			Name = "git 2.14 (x64)"
			ProductId = "Git-2.14.1-64-bit"
			DependsOn = "[xRemoteFile]gitDownload"
			Arguments = "/silent"
			LogPath = "c:\temp\git_InstallLog.log"
		}

	}
}